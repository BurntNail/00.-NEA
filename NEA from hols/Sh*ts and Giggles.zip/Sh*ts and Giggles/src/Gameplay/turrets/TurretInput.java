//package Gameplay.turrets;
//
//import javax.swing.*;
//import java.awt.*;
//import java.util.ArrayList;
//
//public class TurretInput {
//
//    public static String GetInitialTurretInput (ArrayList<String> types, Dimension listSize, Dimension wholeSize) {
//        JFrame win = new JFrame("Which Turret Type?");
//        win.setPreferredSize(wholeSize);
//        win.setLayout(new BorderLayout());
//
//        JLabel label = new JLabel("Please choose the tower type");
//
//        JButton //TODO: This
//
//
//        JScrollPane listScroller = new JScrollPane();
//        listScroller.setPreferredSize(listSize);
//        listScroller.setAlignmentX(Component.LEFT_ALIGNMENT);
//
//        JPanel listPane = new JPanel();
//    }
//
//}
