package classes.Entity;

public enum entityType {

    bullet,
    enemy,
    turret

}
