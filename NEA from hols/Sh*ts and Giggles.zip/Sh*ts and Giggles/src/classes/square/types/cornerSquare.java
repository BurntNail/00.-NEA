package classes.square.types;

import classes.util.Coordinate;

public class cornerSquare extends Square{

    public cornerSquare(String fn, Coordinate xY) {
        super(fn, xY);
    }
}
