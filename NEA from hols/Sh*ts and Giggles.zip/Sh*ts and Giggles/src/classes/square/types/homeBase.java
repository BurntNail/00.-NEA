package classes.square.types;

import classes.util.Coordinate;

public class homeBase extends Square{


    public homeBase(Coordinate xY) {
        super("happy_big.png", xY);
    }
}
