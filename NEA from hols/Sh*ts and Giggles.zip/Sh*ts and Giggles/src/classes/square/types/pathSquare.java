package classes.square.types;

import classes.util.Coordinate;

public class pathSquare extends Square{ //TODO: Corners

    public pathSquare(Coordinate xY) {
        super("general_big.png", xY);
    }
}
