package classes.square.types;

import classes.util.Coordinate;

public class enemyStartSquare extends Square{


    public enemyStartSquare(Coordinate xY) {
        super("satan_big.png", xY);
    }
}
