package classes.square.types;

import classes.util.Coordinate;

public class scenerySquare extends Square{


    public scenerySquare(Coordinate xY) {
        super("nothing_big.png", xY);
    }
}
