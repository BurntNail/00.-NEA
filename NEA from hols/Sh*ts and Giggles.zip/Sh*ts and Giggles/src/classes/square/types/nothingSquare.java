package classes.square.types;

import classes.util.Coordinate;

public class nothingSquare extends Square{

    public nothingSquare(Coordinate xY) {
        super("nothing_big.png", xY);
    }
}
