package classes.util;

public enum dir {

    N,
    S,
    E,
    W,

}
