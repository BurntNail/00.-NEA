There will be no interaction between the canvas and the rest of the game, and the only interaction will be in a seperate class which takes a list of all objects to be renderered, and renders them.

30fps